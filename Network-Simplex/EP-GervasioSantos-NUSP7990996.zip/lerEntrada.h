/****************************************************************
EXERCICIO-PROGRAMA DE MAC0315 - PROGRAMACAO LINEAR
PRIMEIRO SEMESTRE DE 2014
ALUNO: GERVASIO PROTASIO DOS SANTOS NETO
NUSP: 7990996
PROFESSOR: WALTER MASCARENHAS

arquivo: lerEntrada.h
 ****************************************************************/

#ifndef H_ENTRADA_DEFINE
#define H_ENTRADA_DEFINE

#include "grafo.h"

Graph le_entrada(char*);

#endif
